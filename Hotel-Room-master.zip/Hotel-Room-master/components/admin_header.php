<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo">AdminPanel</a>

      <nav class="navbar">
         <a href="dashboard.php">Home</a>
         <a href="bookings.php">Bookings</a>
         <a href="admins.php">Admins</a>
         <a href="messages.php">Messages</a>
         <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');">logout</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

</header>